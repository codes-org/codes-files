This DUMPI trace tarball has been rehosted for purposes of availability due to sporadic outages of the main hosting site.
The tarball was originally downloaded from https://portal.nersc.gov/project/CAL/doe-miniapps-mpi-traces/AMG/df_AMG_n27_dumpi.tar.gz
on the Design Forward mini-app page: https://portal.nersc.gov/project/CAL/designforward.htm
